import React, { useState } from "react";
import axios from "axios";
import {
  Box,
  TextField,
  Button,
  Avatar,
  Typography,
  CircularProgress,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import PersonIcon from "@mui/icons-material/Person";
import SmartToyIcon from "@mui/icons-material/SmartToy";

function App() {
  const [userMessage, setUserMessage] = useState("");
  const [chatHistory, setChatHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!userMessage) return;

    // Add user message to chat history
    const newChatHistory = [
      ...chatHistory,
      { role: "user", content: userMessage },
    ];
    setChatHistory(newChatHistory);

    setLoading(true);
    try {
      const response = await axios.post("http://127.0.0.1:5000/generate-response", {
        message: userMessage,
      });

      // Add AI response to chat history
      setChatHistory((prev) => [
        ...prev,
        { role: "assistant", content: response.data.response },
      ]);
    } catch (error) {
      console.error("Error generating response:", error);
      setChatHistory((prev) => [
        ...prev,
        { role: "assistant", content: "Failed to get a response. Please try again." },
      ]);
    } finally {
      setUserMessage("");
      setLoading(false);
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      height="100vh"
      sx={{
        background: "linear-gradient(to right,rgb(132, 193, 246),rgb(193, 204, 205))", // Gradient background
      }}
    >
      {/* Chat Container */}
      <Box
        padding={2}
        borderRadius={2}
        boxShadow={3}
        width="100%"
        maxWidth="600px"
        height="90vh"
        display="flex"
        flexDirection="column"
        justifyContent="space-between"
        sx={{
          background: "linear-gradient(to bottom, #ffffff, #d7e8ff)", // Chat container gradient
        }}
      >
        {/* Header */}
        <Typography
          variant="h5"
          align="center"
          gutterBottom
          sx={{
            background: "linear-gradient(to right, #ff512f, #dd2476)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            fontWeight: "bold",
          }}
        >
          Buzz
        </Typography>

        {/* Chat History */}
        <Box
          flexGrow={1}
          overflow="auto"
          marginBottom={2}
          padding={1}
        >
          {chatHistory.map((chat, index) => (
            <Box
              key={index}
              display="flex"
              alignItems="flex-start"
              marginBottom={2}
              flexDirection={chat.role === "user" ? "row-reverse" : "row"}
            >
              <Avatar
                sx={{
                  background: chat.role === "user"
                    ? "linear-gradient(to right, #8e2de2, #4a00e0)"
                    : "linear-gradient(to right, #ff512f, #f09819)",
                  margin: "0 8px",
                }}
              >
                {chat.role === "user" ? <PersonIcon /> : <SmartToyIcon />}
              </Avatar>
              <Box
                sx={{
                  background: chat.role === "user"
                    ? "linear-gradient(to right, #43cea2, #185a9d)"
                    : "linear-gradient(to right, #ff9966, #ff5e62)",
                  padding: 2,
                  borderRadius: 2,
                  maxWidth: "75%",
                  boxShadow: 1,
                }}
              >
                <Typography variant="body1" sx={{ color: "#fff" }}>
                  {chat.content}
                </Typography>
              </Box>
            </Box>
          ))}
          {loading && (
            <Box display="flex" justifyContent="center" marginY={2}>
              <CircularProgress size={24} />
            </Box>
          )}
        </Box>

        {/* Input and Send Button */}
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <TextField
            variant="outlined"
            fullWidth
            placeholder="Type your message..."
            value={userMessage}
            onChange={(e) => setUserMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !loading) handleSubmit();
            }}
            sx={{
              marginRight: 1,
              "& .MuiOutlinedInput-root": {
                background: "#fff",
                borderRadius: 2,
              },
            }}
          />
          <Button
            variant="contained"
            sx={{
              background: "linear-gradient(to right, #ff7e5f, #feb47b)",
              color: "#fff",
              "&:hover": {
                background: "linear-gradient(to right, #feb47b, #ff7e5f)",
              },
            }}
            onClick={handleSubmit}
            disabled={loading || !userMessage}
            endIcon={<SendIcon />}
          >
            Send
          </Button>
        </Box>
      </Box>
    </Box>
  );
}

export default App;
