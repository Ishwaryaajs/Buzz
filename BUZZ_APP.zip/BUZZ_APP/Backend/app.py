from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os
import openai
import traceback

# Load environment variables
load_dotenv()

# Flask app setup
app = Flask(__name__)
CORS(app)

# Azure OpenAI settings
openai.api_type = "azure"
openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
openai.api_base = os.getenv("AZURE_OPENAI_ENDPOINT")
openai.api_version = os.getenv("OPENAI_API_VERSION")


@app.route('/generate-response', methods=['POST'])
def generate_response():
    try:
        # Extract the message from the request
        data = request.json
        user_message = data.get("message", "What is LLM?")
        if not user_message:
            raise ValueError("No message provided in the request payload")

        # Call Azure OpenAI API
        response = openai.ChatCompletion.create(
            engine="gpt-4o-mini",  # Replace with your deployed model name
            messages=[
                {"role": "system", "content": "You are an AI assistant."},
                {"role": "user", "content": user_message}
            ],
            temperature=0.7,
            max_tokens=256,
            top_p=0.6,
            frequency_penalty=0.7
        )

        # Extract the AI response and return it
        ai_response = response["choices"][0]["message"]["content"]
        return jsonify({"response": ai_response})

    except Exception as e:
        # Log the error with traceback for debugging
        print("Error occurred:", e)
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
